YPbPr-only analog timing work: hardware validation pending

The separate CoCoTANG-ypbpr-analog.gprj substitutes only the top and encoder
from src/ypbpr/. RGB, CVBS and PAL retain their confirmed projects and sources.
The initial implementation ports the confirmed PAL analog counters/read
address and exact RGB222 lookup conversion, without enabling PAL chroma.
Shared CPU, SDRAM, SSC, IDE, GIME, IRQ and HDMI logic are unchanged.
Component Y/Pb/Pr levels, register latency and DAC phase settings are preserved.

Original placement settings are copied to this project's own process config:
place1, route1, replication=true, maxfan16. No placement tuning is permitted.

Build: make rebuild-ypbpr
Timing: make timing-ypbpr
Tests: make test-ypbpr

A timing pass is not hardware confirmation. Save each passing candidate with
its exact sources and test cold boot and Boink on both component and HDMI.

Timing experiments:
- Initial isolated PAL-derived analog logic: 108=104.806, 135=113.659,
  270=227.747 MHz. All waveform tests pass; not offered for hardware testing.
- Exact registered RGB222-to-component lookup: 108=102.655, 135=137.923,
  270=262.847 MHz. All component bits and DAC tests match the original.
- Current trial moves neutral/colour carry selection before the last IO flop,
  predicting the existing phase and next sigma carry. The output latency and
  accumulator residue remain unchanged; waveform comparisons pass.

The early output selection trial passed 270 MHz (364.787 MHz), but clk108
106.610 MHz and clk135 134.475 MHz missed timing. The current trial combines
the Pb/Pr tables to share colour decoding. The component DAC comparison also
checks both phase settings over resets, sync restarts and 80000 abrupt level
transitions, with bit-identical output to the original encoder.

The combined Pb/Pr ROM synthesized to the same implementation and timing as
the separate tables. The next trial moves the picture/blank selection into
the preceding component-level register, preserving the original picture flag
alignment and output latency. Full waveform and DAC transition tests pass.

Passing candidate: impl/pnr/ypbpr-early-blank-test.fs
clk108=108.251, clk135=135.288, clk270=328.907 MHz; all clocks meet timing,
zero setup/hold violated endpoints. Hardware boot/Boink confirmation pending.
RGB/CVBS/PAL sources, images and placement settings are unchanged.
Flash, then fully power-cycle the CoCo before boot/Boink and hi-res testing:
openFPGALoader -b tangnano20k -f impl/pnr/ypbpr-early-blank-test.fs
