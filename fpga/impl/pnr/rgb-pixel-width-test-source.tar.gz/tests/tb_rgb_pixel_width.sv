`timescale 1ns/1ps
// Production RGB raster, top-level request register, paged cache and encoder.
// Count every displayed stroke, including both edges and RAM page crossings.
module tb_rgb_pixel_width;
 reg clk=0, reset_n=0, compatibility=0, standard=0;
 always #4 clk=~clk;
 wire [9:0] raw_x,raw_address;
 wire raw_valid;
 reg [9:0] read_x=0,read_address=0;
 reg valid=0,last_request=0;
 wire [5:0] pixel;
 always @(posedge clk)begin
  if(!reset_n)begin read_x<=0;read_address<=0;valid<=0;last_request<=0;end
  else begin
   last_request<=raw_x[9:1]==319;
   read_x<={raw_x[9:1],raw_x[0]&&!last_request};
   read_address<=raw_valid?raw_address:10'd0;
   valid<=raw_valid;
  end
 end
 coco_cvbs_ntsc #(.CANONICAL_640_INPUT(1),.CVBS_INCREMENTAL_DOTS(1),
  .CVBS_FAST_PREFETCH(1),.YPBPR_TO_RGB_LUT(1),
  .RGB_SCANLINE_PHASE_ALTERNATION(1),.LUMA_SCANLINE_PHASE_ALTERNATION(1),
  .LUMA_DAC_EVEN_LEVELS(1)) dut(
  .clk135(clk),.clk270(clk),.reset_n(reset_n),.video_50hz(standard),
  .high_resolution(1'b1),.compatibility_mode(compatibility),
  .active_height(8'd192),.framebuffer_data(pixel),.border_rgb(6'd0),
  .row_border_rgb(6'd0),.row_right_border_rgb(6'd0),
  .row_border_valid(1'b1),.vertical_border_valid(1'b0),
  .source_x(raw_x),.source_read_address(raw_address),.source_valid(raw_valid));
 gime_scanline_buffer #(.CVBS_REGISTERED_READ_ADDRESS(1)) cache(
  .clk(clk),.reset_n(1'b0),.cvbs_read_clk(clk),.cvbs_read_x(read_x),
  .cvbs_read_address(read_address),.cvbs_display_y(8'd0),
  .cvbs_display_valid(valid),.cvbs_pixel_data(pixel));
 for(genvar page=0;page<10;page=page+1)begin:pages
  integer offset;
  always @(negedge reset_n)for(offset=0;offset<64;offset=offset+1)
   cache.cvbs_pages[page].line0[offset]=
    ((compatibility?((page*64+offset)*2/5):(page*64+offset))%2)?6'h03:6'h30;
 end
 integer mode,hz,tick,stage,runs[0:1],width[0:1],expected_width;
 reg [5:0] previous[0:1],sample_rgb;
 task check_run(input integer s);
  begin
   if(width[s]!=expected_width)
    $fatal(1,"RGB %0dHz compat=%0d stage=%0d stroke=%0d width=%0d expected=%0d",
     hz?50:60,mode,s,runs[s],width[s],expected_width);
   if(previous[s]!==(runs[s]%2?6'h03:6'h30))$fatal(1,"RGB stroke order %0d",runs[s]);
   runs[s]=runs[s]+1;
  end
 endtask
 initial begin
  force cache.c_valid0=1;force cache.c_tag0=0;
  force cache.c_valid1=0;force cache.c_valid2=0;
  for(hz=0;hz<2;hz=hz+1)for(mode=0;mode<2;mode=mode+1)begin
   compatibility=mode;standard=hz;reset_n=1;
   @(negedge clk);reset_n=0;
   repeat(4)@(negedge clk);reset_n=1;
   repeat(12)@(negedge clk);
   force dut.h_sample=0;force dut.sample_phase=0;force dut.v_line=70;
   @(negedge clk);
   release dut.h_sample;release dut.sample_phase;release dut.v_line;
   for(stage=0;stage<2;stage=stage+1)begin
    runs[stage]=0;width[stage]=0;previous[stage]=0;
   end
   expected_width=mode?20:10;
   for(tick=0;tick<(hz?8640:8580);tick=tick+1)begin
    @(negedge clk);
    for(stage=0;stage<2;stage=stage+1)begin
     if(stage==0)sample_rgb=dut.pixel_rgb;
     else case(dut.inverse_rgb)
      {7'd40,7'd0,7'd96}:sample_rgb=6'h30;
      {7'd40,7'd96,7'd0}:sample_rgb=6'h03;
      21'd0,{7'd40,7'd0,7'd0}:sample_rgb=0;
      default:$fatal(1,"Unexpected RGB DAC levels %h",dut.inverse_rgb);
     endcase
     if(sample_rgb!==previous[stage])begin
      if(previous[stage]!=0)check_run(stage);
      width[stage]=0;previous[stage]=sample_rgb;
     end
     if(previous[stage]!=0)width[stage]=width[stage]+1;
    end
   end
   for(stage=0;stage<2;stage=stage+1)begin
    if(previous[stage]!=0)check_run(stage);
    if(runs[stage]!=(mode?256:640))$fatal(1,"RGB missing strokes: %0d",runs[stage]);
   end
   $display("RGB %0dHz compat=%0d: %0d equal strokes of %0d clocks through inverse LUT PASS",
    hz?50:60,mode,runs[1],expected_width);
  end
  $finish;
 end
endmodule
