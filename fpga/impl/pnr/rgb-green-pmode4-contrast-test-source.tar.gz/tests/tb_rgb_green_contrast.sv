`timescale 1ns/1ps
module tb_rgb_green_contrast;
 reg clk=0,fast_clk=0,reset_n=0,pmode4=0,css=0;
 reg [5:0] color=0;
 always #4 clk=~clk;
 always #2 fast_clk=~fast_clk;
 wire [2:0] actual_bits,original_bits;
 wire [5:0] reference_color=(pmode4&&!css)?
  (color==6'h04 ? 6'h00 : color==6'h18 ? 6'h0c : color):color;
 coco_cvbs_ntsc #(.CANONICAL_640_INPUT(1),.CVBS_INCREMENTAL_DOTS(1),
  .CVBS_FAST_PREFETCH(1),.YPBPR_TO_RGB_LUT(1),
  .RGB_SCANLINE_PHASE_ALTERNATION(1),.LUMA_SCANLINE_PHASE_ALTERNATION(1),
  .LUMA_DAC_EVEN_LEVELS(1),.RGB_GREEN_CONTRAST(1)) dut(
  .clk135(clk),.clk270(fast_clk),.reset_n(reset_n),.video_50hz(1'b0),
  .high_resolution(1'b1),.compatibility_mode(1'b1),.active_height(8'd192),
  .framebuffer_data(color),.green_pmode4_contrast(pmode4&&!css),
  .border_rgb(6'd0),.row_border_valid(1'b0),
  .vertical_border_valid(1'b0),.luma_out(actual_bits[2]),
  .component_pb_out(actual_bits[1]),.component_pr_out(actual_bits[0]));
 coco_cvbs_ntsc #(.CANONICAL_640_INPUT(1),.CVBS_INCREMENTAL_DOTS(1),
  .CVBS_FAST_PREFETCH(1),.YPBPR_TO_RGB_LUT(1),
  .RGB_SCANLINE_PHASE_ALTERNATION(1),.LUMA_SCANLINE_PHASE_ALTERNATION(1),
  .LUMA_DAC_EVEN_LEVELS(1)) original(
  .clk135(clk),.clk270(fast_clk),.reset_n(reset_n),.video_50hz(1'b0),
  .high_resolution(1'b1),.compatibility_mode(1'b1),.active_height(8'd192),
  .framebuffer_data(reference_color),.border_rgb(6'd0),.row_border_valid(1'b0),
  .vertical_border_valid(1'b0),.luma_out(original_bits[2]),
  .component_pb_out(original_bits[1]),.component_pr_out(original_bits[0]));
 function automatic [6:0] green(input [1:0] level);
  case(level)0:green=40;1:green=58;2:green=80;3:green=102;endcase
 endfunction
 function automatic [6:0] channel(input [1:0] level);
  case(level)0:channel=0;1:channel=42;2:channel=74;3:channel=96;endcase
 endfunction
 reg checking=0,check_green_waveform=0;
 always @(negedge fast_clk)if(checking && (!(pmode4&&!css)||check_green_waveform))begin
  if(actual_bits!==original_bits || dut.inverse_rgb!==original.inverse_rgb)
   $fatal(1,"Buff/non-PMODE4 DAC waveform changed mode=%b/%b color=%h RGB=%h/%h bits=%b/%b",pmode4,css,color,dut.inverse_rgb,original.inverse_rgb,actual_bits,original_bits);
 end
 integer mode,i,tick;
 reg [5:0] expected;
 initial begin
  for(mode=0;mode<3;mode=mode+1)begin
   checking=0;reset_n=0;pmode4=mode!=0;css=mode==1;
   repeat(4)@(negedge clk);
   force dut.h_sample=300;force dut.sample_phase=0;force dut.v_line=70;
   force original.h_sample=300;force original.sample_phase=0;force original.v_line=70;
   reset_n=1;@(negedge clk);
   release dut.h_sample;release dut.sample_phase;release dut.v_line;
   release original.h_sample;release original.sample_phase;release original.v_line;
   checking=1;
   for(i=0;i<64;i=i+1)begin
    color=6'(i);expected=color;
    if(mode==2)case(color)
     6'h04:expected=0;6'h18:expected=6'h0c;
    endcase
    repeat(32)@(negedge clk);
    if(mode!=2 || color==0 || color==6'h04 || color==6'h08 || color==6'h14 || color==6'h18)
     if(dut.inverse_rgb!=={green(expected[3:2]),channel(expected[1:0]),channel(expected[5:4])})
      $fatal(1,"Wrong analog palette mode=%0d input=%h DAC=%h",mode,color,dut.inverse_rgb);
   end
   $display("RGB green contrast mode=%0d: %0d DAC colours PASS",mode,mode==2?5:64);
  end
  checking=0;reset_n=0;color=0;pmode4=1;css=0;
  repeat(4)@(negedge clk);
  force dut.h_sample=300;force dut.sample_phase=0;force dut.v_line=70;
  force original.h_sample=300;force original.sample_phase=0;force original.v_line=70;
  reset_n=1;@(negedge clk);
  release dut.h_sample;release dut.sample_phase;release dut.v_line;
  release original.h_sample;release original.sample_phase;release original.v_line;
  repeat(32)@(negedge clk);checking=1;check_green_waveform=1;
  for(tick=0;tick<512;tick=tick+1)begin
   case(tick%5)0:color=0;1:color=6'h04;2:color=6'h08;3:color=6'h14;4:color=6'h18;endcase
   @(negedge clk);
  end
  $display("Green PMODE4 rapid-transition DAC waveform matches reference PASS");
  $display("Buff and non-PMODE4 DAC pulse streams remain identical PASS");
  $finish;
 end
endmodule
