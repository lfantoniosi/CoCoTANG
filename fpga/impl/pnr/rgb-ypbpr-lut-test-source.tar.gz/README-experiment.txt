YPbPr-base RGB inverse-LUT experiment

Build: make rebuild-rgb
Project identity: CoCoTANG-pal.gprj, top_coco3_rgb, CoCoTANG-rgb output.
Placement stays place1/route0/replication enabled/maxfan16, as the RGB baseline.
No project, clock, timing constraint, synthesis optimization or placement setting was tuned.

The shared RGB encoder/top in this snapshot are copies of the confirmed YPbPr
RTL with an exact inverse LUT added before the DACs. The src/ypbpr, src/pal
and src/cvbs variants are not dependencies of this RGB project. The original
working-tree variants and confirmed images were not modified.

Every RGB222 colour is recovered exactly from the quantized component tuple.
Six per-bit inverse tables use 336 bits total. Component channels are aligned
before conversion, and sync/blanking follow the registered colour pipeline.
The 64 calibrated colours, DAC densities, rapid transitions, and RGB phase
seeds were checked. The artifact decoder and HDMI palette are unchanged.

This intentionally uses the YPbPr scanout geometry rather than the confirmed
RGB CoCo-dot aperture. The conversion adds two clk135 stages after the Y stage;
colour and sync receive the same added delay. Hardware cold boot, both displays,
artifact modes and Boink have NOT been confirmed for this experimental image.

Other retained RTL changes: a phase-only mux scanner with unchanged settling
and early address publication; CPU-order address capture; a width-bounded
1080-cycle refresh counter with the exact original grant schedule; parallel
prefetch boundary comparisons. CPU/SDRAM transaction timing is unchanged.

Verification: final-inverse-test.sv checks all 64 colours, output pulse density,
8192 colour/control transitions, pipeline latency and alternating DAC phases.
It can be compiled with src/video/coco_cvbs_ntsc.v using Icarus Verilog.
The arbiter differential test checks all outputs/counts for 30000 cycles.
The mux test checks all high address bytes and address/control publication.
