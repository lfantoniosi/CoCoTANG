`timescale 1ns/1ps
module tb_ypbpr_rgb_inverse;
 reg clk135=0,clk270=0,reset_n=0;reg[5:0] color=0;integer i,j,tick,sample,green_pulses,blue_pulses,red_pulses;reg picture=1,sync_level=0;
 reg[5:0] history[0:5];reg[2:0] picture_history=0,sync_history=0;
 reg[6:0] rb[0:3],green[0:3];reg[20:0] expected;
 always #4 clk135=~clk135;always #2 clk270=~clk270;
 coco_cvbs_ntsc #(.CANONICAL_640_INPUT(1),.CVBS_INCREMENTAL_DOTS(1),
 .RGB_SOG_OUTPUT(0),.YPBPR_TO_RGB_LUT(1),.RGB_SCANLINE_PHASE_ALTERNATION(1),.LUMA_SCANLINE_PHASE_ALTERNATION(1),.LUMA_DAC_EVEN_LEVELS(1)) dut(
 .clk135(clk135),.clk270(clk270),.reset_n(reset_n),.video_50hz(1'b0),
 .high_resolution(1'b1),.compatibility_mode(1'b0),.framebuffer_data(color),
 .border_rgb(6'd0),.row_border_rgb(6'd0),.row_right_border_rgb(6'd0),
 .row_border_valid(1'b0),.vertical_left_border_rgb(6'd0),
 .vertical_right_border_rgb(6'd0),.vertical_border_valid(1'b0),.active_height(8'd192));
 always @(posedge clk135)begin
  history[0]<=color;for(j=1;j<6;j=j+1)history[j]<=history[j-1];
  picture_history<={picture_history[1:0],picture};
  sync_history<={sync_history[1:0],sync_level};
 end
 task check_output;
  begin
   if(sync_history[2])expected=0;
   else if(!picture_history[2])expected={7'd40,7'd0,7'd0};
   else expected={green[history[5][3:2]],rb[history[5][1:0]],rb[history[5][5:4]]};
   if(dut.inverse_rgb!==expected)
    $fatal(1,"inverse RGB mismatch tick=%0d colour=%0d expected=%h got=%h Y=%0d Pr=%0d",tick,history[5],expected,dut.inverse_rgb,dut.luma_level_135,dut.inverse_pr);
  end
 endtask
 initial begin
  force dut.pixel_rgb=color;force dut.level_sync=sync_level;
  force dut.level_picture=picture;
  rb[0]=0;rb[1]=42;rb[2]=74;rb[3]=96;
  green[0]=40;green[1]=58;green[2]=80;green[3]=102;
  for(i=0;i<6;i=i+1)history[i]=0;
  repeat(4)@(negedge clk135);reset_n=1;
  repeat(12)@(negedge clk135);
  for(i=0;i<64;i=i+1)begin
   color=i;repeat(20)@(negedge clk135);check_output();
   green_pulses=0;blue_pulses=0;red_pulses=0;
   for(sample=0;sample<128;sample=sample+1)begin
    @(negedge clk270);
    green_pulses=green_pulses+dut.luma_out;
    blue_pulses=blue_pulses+dut.component_pb_out;
    red_pulses=red_pulses+dut.component_pr_out;
   end
   if(green_pulses!=green[color[3:2]] || blue_pulses!=rb[color[1:0]] || red_pulses!=rb[color[5:4]])
    $fatal(1,"RGB DAC density changed for colour %0d: %0d/%0d/%0d",color,red_pulses,green_pulses,blue_pulses);
  end
  for(tick=0;tick<8192;tick=tick+1)begin
   color=(tick*37)^(tick>>3);picture=tick%19>2;sync_level=tick%19==0;
   @(negedge clk135);check_output();
  end
  $display("YPbPr inverse LUT PASS: all 64 RGB222 colours/DAC densities, 8192 rapid transitions, sync/blanking and pipeline alignment");
  $finish;
 end
endmodule
