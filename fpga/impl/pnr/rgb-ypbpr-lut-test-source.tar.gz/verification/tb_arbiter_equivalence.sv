`timescale 1ns/1ps
module tb_arbiter_equivalence;
 reg clk=0;
 reg reset_n=0;
 reg e=0;
 reg q=0;
 reg cpu_req=0;
 reg cpu_wr=0;
 reg [22:0] cpu_addr=0;
 reg [7:0] cpu_wdata=0;
 reg video_req=0;
 reg [22:0] video_addr=0;
 reg video_slot_open=0;
 reg refresh_slot_open=0;
 reg loader_req=0;
 reg loader_wr=0;
 reg [22:0] loader_addr=0;
 reg [7:0] loader_wdata=0;
 reg [15:0] dout=0;
 reg [31:0] dout32=0;
 reg data_ready=0;
 reg busy=0;
 reg enabled=0;
 cpu_sdram_arbiter dut(.clk(clk),
.reset_n(reset_n),
.e(e),
.q(q),
.cpu_req(cpu_req),
.cpu_wr(cpu_wr),
.cpu_addr(cpu_addr),
.cpu_wdata(cpu_wdata),
.video_req(video_req),
.video_addr(video_addr),
.video_slot_open(video_slot_open),
.refresh_slot_open(refresh_slot_open),
.loader_req(loader_req),
.loader_wr(loader_wr),
.loader_addr(loader_addr),
.loader_wdata(loader_wdata),
.dout(dout),
.dout32(dout32),
.data_ready(data_ready),
.busy(busy),
.enabled(enabled),
.cpu_ack(),
.cpu_rdata(),
.video_ack(),
.video_rdata(),
.loader_ack(),
.loader_rdata(),
.rd(),
.wr(),
.refresh(),
.addr(),
.din(),
.wdm());
 cpu_sdram_arbiter_reference reference(.clk(clk),
.reset_n(reset_n),
.e(e),
.q(q),
.cpu_req(cpu_req),
.cpu_wr(cpu_wr),
.cpu_addr(cpu_addr),
.cpu_wdata(cpu_wdata),
.video_req(video_req),
.video_addr(video_addr),
.video_slot_open(video_slot_open),
.refresh_slot_open(refresh_slot_open),
.loader_req(loader_req),
.loader_wr(loader_wr),
.loader_addr(loader_addr),
.loader_wdata(loader_wdata),
.dout(dout),
.dout32(dout32),
.data_ready(data_ready),
.busy(busy),
.enabled(enabled),
.cpu_ack(),
.cpu_rdata(),
.video_ack(),
.video_rdata(),
.loader_ack(),
.loader_rdata(),
.rd(),
.wr(),
.refresh(),
.addr(),
.din(),
.wdm());
 always #5 clk=~clk;
 integer i;
 initial begin
 repeat(2)@(negedge clk);reset_n=1;
 for(i=0;i<30000;i=i+1)begin
 @(negedge clk);
 e=$urandom;
 q=$urandom;
 cpu_req=$urandom;
 cpu_wr=$urandom;
 cpu_addr=$urandom;
 cpu_wdata=$urandom;
 video_req=$urandom;
 video_addr=$urandom;
 video_slot_open=$urandom;
 refresh_slot_open=$urandom;
 loader_req=$urandom;
 loader_wr=$urandom;
 loader_addr=$urandom;
 loader_wdata=$urandom;
 dout=$urandom;
 dout32=$urandom;
 data_ready=$urandom;
 busy=$urandom;
 enabled=$urandom;
 reset_n=i%2500!=0;
 @(posedge clk);#1;
if({dut.cpu_ack,dut.cpu_rdata,dut.video_ack,dut.video_rdata,dut.loader_ack,dut.loader_rdata,dut.rd,dut.wr,dut.refresh,dut.addr,dut.din,dut.wdm} !== {reference.cpu_ack,reference.cpu_rdata,reference.video_ack,reference.video_rdata,reference.loader_ack,reference.loader_rdata,reference.rd,reference.wr,reference.refresh,reference.addr,reference.din,reference.wdm})$fatal(1,"Arbiter output/timing mismatch cycle %0d",i);
if(dut.refresh_count!==reference.refresh_count)$fatal(1,"Refresh schedule mismatch cycle %0d",i);
end
$display("Arbiter equivalence PASS: 30000 cycles, all outputs and refresh counts identical");$finish;
end
endmodule
