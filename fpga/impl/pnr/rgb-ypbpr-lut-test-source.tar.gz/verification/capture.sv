`timescale 1ns/1ps
module capture;
 reg clk135=0,clk270=0,reset_n=0;reg[5:0] color=0;integer i,f;
 always #4 clk135=~clk135;always #2 clk270=~clk270;
 coco_cvbs_ntsc #(.CANONICAL_640_INPUT(1),.CVBS_INCREMENTAL_DOTS(1),
 .RGB_SOG_OUTPUT(0),.LUMA_DAC_EVEN_LEVELS(1)) dut(
 .clk135(clk135),.clk270(clk270),.reset_n(reset_n),.video_50hz(1'b0),
 .high_resolution(1'b1),.compatibility_mode(1'b0),.framebuffer_data(color),
 .border_rgb(6'd0),.row_border_rgb(6'd0),.row_right_border_rgb(6'd0),
 .row_border_valid(1'b0),.vertical_left_border_rgb(6'd0),
 .vertical_right_border_rgb(6'd0),.vertical_border_valid(1'b0),.active_height(8'd192));
 initial begin
  force dut.pixel_rgb=color;force dut.level_sync=0;
  force dut.level_picture=1;force dut.mod_picture=1;
  f=$fopen("/private/tmp/rgb-ypbpr-lut/levels.txt","w");
  repeat(4)@(negedge clk135);reset_n=1;
  for(i=0;i<64;i=i+1)begin
   color=i;repeat(20)@(negedge clk135);
   $fdisplay(f,"%0d %0d %0d %0d",i,dut.luma_level_135,dut.component_pb_level_135,dut.component_pr_level_135);
  end
  $fclose(f);$finish;
 end
endmodule
